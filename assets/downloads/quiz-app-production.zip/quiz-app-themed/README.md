# Quiz App - Powered by KetraLabs

A modern, responsive HTML5 quiz application that runs entirely locally in your browser. Perfect for exam preparation and any custom quiz needs.

**Developed by [KetraLabs](https://ketralabs.com)** - Professional software development for educational technology.

## 🚀 Features

- **File Upload Support**: Excel (.xlsx, .xls), CSV, JSON formats
- **Excel Template**: Quick-access Excel template download button
- **Configurable Time Limits**: Auto-calculated based on question count (1min 10sec per question)
- **Study Mode**: Optional immediate feedback with correct answers
- **Progress Tracking**: Save and resume quiz progress
- **Dark/Light Theme**: Toggle between themes
- **Mobile Responsive**: Works on all devices
- **100% Offline**: No server dependencies required

## 📁 File Structure

```
quiz-app/
├── index.html          # Main application file
├── css/
│   └── style.css       # Custom styles and theme support
├── js/
│   └── app.js          # Main application logic
├── test-data.csv       # Sample quiz data (9 CSA questions)
├── templates/          # Template files (generated on demand)
├── README.md           # This file
└── DEPLOYMENT.md       # Deployment guide
```

## 🛠️ Setup Instructions

### Option 1: Direct Browser Opening (Recommended for POC)
1. Download or clone this repository
2. Open `index.html` directly in your browser
3. The app will work immediately with all features

### Option 2: Local Server (Optional)
If you prefer to run with a local server:
```bash
# Using Python 3
python -m http.server 8000

# Using Node.js
npx http-server

# Using PHP
php -S localhost:8000
```

Then open `http://localhost:8000` in your browser.

## 📊 Data Format

The app supports three file formats with the same data structure:

### Excel/CSV Format
| Column A | Column B | Column C | Column D | Column E | Column F | Column G | ... |
|----------|----------|----------|----------|----------|----------|----------|-----|
| Question | Correct Answer | Option A | Option B | Option C | Option D | Option E | ... |

### JSON Format
```json
[
  {
    "question": "What is cloud computing?",
    "optionA": "A distributed computing model",
    "optionB": "Local server hosting",
    "optionC": "Desktop application",
    "optionD": "None of the above",
    "optionE": "All of the above",
    "correctAnswer": "A"
  }
]
```

### Important Notes:
- **Question**: Required text for the question
- **Correct Answer**: Single letter (A, B, C, D, E, F, G...) or comma-separated for multiple correct answers
- **Options**: Answer choices (minimum 2 required, unlimited maximum up to A-Z)
- **Header Row**: First row is treated as header and skipped
- **Empty Options**: Leave blank if not needed - app automatically adapts to any number of options

## 🧪 Quick Start with Test Data

For immediate testing without creating your own questions:

1. **Open `index.html`** in your browser
2. **Click "Load Test Data (9 Anuraj Questions)"** button
3. **Click "Configure Quiz"** to start immediately

### Test Data Included
The built-in test data contains 9 sample Anuraj questions covering:
- **5-option questions**: Cloud computing basics, AWS identification
- **4-option questions**: Cloud service models  
- **3-option questions**: Cloud provider identification, virtualization
- **True/False questions**: Basic cloud concepts
- **Multi-select questions**: Multiple correct answers

## 🎯 How to Use

### 1. Get Started
1. Open `index.html` in your browser
2. **Option A**: Use "Load Test Data" for immediate testing
3. **Option B**: Download the Excel template (small button in top-right corner) and fill in your questions

### 2. Upload Your Data
1. Click the upload area or drag & drop your file
2. Supported formats: Excel (.xlsx, .xls), CSV, JSON
3. The app will validate and process your data

### 3. Configure Quiz
1. Review the number of questions loaded
2. Adjust time limit if needed (auto-calculated: 1min 10sec per question)
3. Enable study mode for immediate feedback (optional)
4. Click "Start Quiz"

### 4. Take the Quiz
- Navigate between questions using Previous/Next buttons
- Use question number navigation for quick jumps
- Timer shows remaining time
- Progress bar indicates completion status
- Toggle theme anytime during the quiz

### 5. Review Results
- See your score (fraction and percentage)
- Review incorrect answers with correct answers highlighted
- Restart quiz or upload new file

## 🔧 Technical Details

### Browser Compatibility
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

### Dependencies (CDN)
- **Bootstrap 5.3.0**: UI framework
- **SheetJS 0.18.5**: Excel file processing
- **Papa Parse 5.4.1**: CSV file processing
- **Bootstrap Icons 1.10.0**: Icons

### Local Storage
The app uses browser localStorage to save:
- Quiz data
- User progress
- Theme preference
- Quiz settings

### File Processing
- **Excel**: Uses SheetJS library for .xlsx/.xls files
- **CSV**: Uses Papa Parse for comma-separated values
- **JSON**: Native JavaScript JSON parsing

## 🎨 Customization

### Themes
The app includes a built-in dark/light theme system:
- Toggle theme button in top-right corner
- Excel template download button positioned below theme toggle
- Theme preference saved in localStorage
- Smooth transitions between themes

### Styling
Customize the appearance by modifying `css/style.css`:
- Color variables in `:root` selector
- Dark theme variables in `[data-theme="dark"]`
- Responsive breakpoints for mobile devices

## 🐛 Troubleshooting

### Common Issues

**File won't upload:**
- Check file format (Excel, CSV, JSON only)
- Ensure file is not corrupted
- Try a smaller file size

**Questions not loading:**
- Verify data format matches template
- Check that questions have at least 2 options
- Ensure correct answer column is filled

**App not working:**
- Try refreshing the page
- Clear browser cache and localStorage
- Check browser console for errors

### Browser Console Errors
If you see errors in the browser console:
1. Check that all CDN links are accessible
2. Verify file format is supported
3. Ensure JavaScript is enabled

## 📱 Mobile Usage

The app is fully responsive and works on mobile devices:
- Touch-friendly interface
- Optimized for small screens
- Swipe gestures supported
- Portrait and landscape orientations

## 🔒 Privacy & Security

- **No Data Sent**: All processing happens locally in your browser
- **No Tracking**: No analytics or tracking code
- **Local Storage**: Data stored only in your browser
- **File Privacy**: Files are processed locally, never uploaded to servers

## 📋 Recent Updates

### v1.5 - UI Improvements (Latest)
- **🎨 Streamlined Interface**: Moved Excel template download to compact button in top-right corner
- **🧹 Cleaner Layout**: Removed template downloads section for simplified welcome screen
- **📊 Focus on Excel**: Primary template format emphasized with easy access
- **🔧 Better Organization**: Template access positioned logically next to theme toggle

### v1.4 - Schema Refactoring & Unlimited Options
- **🔧 Critical Bug Fix**: Fixed JSON processing that was completely broken in previous versions
- **📊 New Data Schema**: Restructured from `Question|A|B|C|D|E|Answer` to `Question|Answer|A|B|C|...`
- **🚀 Unlimited Options**: Now supports 2-26 options per question (A-Z) dynamically
- **📝 Updated Templates**: All CSV/Excel templates use new intuitive schema format
- **💾 Improved JSON Support**: Fixed and enhanced JSON object processing with optionA/B/C structure
- **📖 Better Documentation**: Comprehensive format examples and improved clarity across all docs

### v1.3 - Navigation Improvements
- **Enhanced**: Question navigation now uses responsive square grid layout
- **Better Organization**: Questions arranged in organized rows instead of long single line
- **Responsive**: Adjusts grid columns based on screen size (5 on desktop, 4 on tablet, 3 on mobile)
- **Visual Enhancement**: Added background container and square buttons for better visual grouping

### v1.2 - Answer Order Consistency
- **Simplified**: Removed answer option shuffling for consistent presentation
- **Improved**: Options now always display in A, B, C, D, E order
- **Better UX**: Predictable answer order for easier navigation

### v1.1 - Data Validation Improvements
- **Fixed**: Removed invalid section headers (`=== EXAMPLE ===`) from all data sources
- **Improved**: Test data now contains only 9 valid, answerable questions
- **Enhanced**: All templates (Excel, CSV, JSON) now provide clean sample data
- **Consistent**: Unified data validation across file upload and test data paths
- **Better UX**: No more unanswerable questions during quiz

### v1.0 - Initial Release
- Complete quiz application with file upload support
- Dark/light theme system
- Progress tracking and resume functionality
- Mobile-responsive design
- 100% offline operation

## 🚀 Future Enhancements

Potential features for future versions:
- Multiple quiz sets support
- Export results functionality
- Question explanations
- Advanced analytics
- Cloud storage integration
- Offline PWA capabilities

## 📄 License

This is a proof-of-concept application. Feel free to modify and use for your own projects.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review browser console for error messages
3. Verify your data format matches the templates

---

## 🏢 About KetraLabs

This Quiz App is developed and maintained by **[KetraLabs](https://ketralabs.com)** - a software development company specializing in educational technology and web applications.

### Why KetraLabs?

- ✅ **Custom Development**: Need specific features? We build tailored solutions
- ✅ **Enterprise Support**: Professional support for organizations
- ✅ **Integration Services**: Connect with your existing systems
- ✅ **Training & Consulting**: Expert guidance for your projects

**Contact Us**: [ketralabs.com/contact](https://ketralabs.com/contact)

---

**Powered by KetraLabs** | [Visit Website](https://ketralabs.com) | **Happy Quizzing! 🎉**
