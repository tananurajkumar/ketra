// CSA Quiz App - Main JavaScript File

class QuizApp {
    constructor() {
        this.quizData = null;
        this.originalQuestions = null; // Store original question order
        this.originalQuizData = null; // Store original quiz data for V2 approach
        this.currentQuestionIndex = 0;
        this.userAnswers = {};
        this.quizStartTime = null;
        this.quizEndTime = null;
        this.timeLimit = 0; // in minutes
        this.studyMode = false;
        this.selectionCounterEnabled = true;
        this.shuffleQuestionsEnabled = false;
        this.shuffleOptionsEnabled = false;
        this.shuffleOptionsV2Enabled = false;
        this.currentTheme = 'light';
        this.currentFont = 'montserrat';
        
        this.initializeApp();
    }

    initializeApp() {
        this.loadSavedData();
        this.setupEventListeners();
        this.applyTheme();
        this.applyFont();
        this.showScreen('welcome');
        // Ensure button is disabled on initialization if no data
        if (!this.quizData) {
            document.getElementById('start-quiz-btn').disabled = true;
        }
    }

    // Theme Management (using new theme loader)
    setTheme(themeName) {
        if (window.themeLoader && window.themeLoader.isReady()) {
            window.themeLoader.switchTheme(themeName);
            this.currentTheme = themeName;
        } else {
            // Fallback for when theme loader isn't ready
            this.currentTheme = themeName;
            document.body.setAttribute('data-theme', this.currentTheme);
        }
        this.updateThemeUI();
    }

    applyTheme() {
        if (window.themeLoader && window.themeLoader.isReady()) {
            window.themeLoader.applyTheme(this.currentTheme);
        } else {
            // Fallback
            document.body.setAttribute('data-theme', this.currentTheme);
        }
        this.updateThemeUI();
    }

    updateThemeUI() {
        // Update current theme display
        const currentThemeSpan = document.getElementById('current-theme');
        if (currentThemeSpan) {
            currentThemeSpan.textContent = this.getThemeDisplayName(this.currentTheme);
        }

        // Update quiz screen theme toggle if it exists
        const quizThemeToggle = document.getElementById('theme-toggle-quiz');
        if (quizThemeToggle) {
            const isDark = this.currentTheme === 'modern';
            const themeIcon = isDark ? 'bi-sun' : 'bi-moon';
            quizThemeToggle.innerHTML = `<i class="bi ${themeIcon}"></i>`;
        }
    }

    getThemeDisplayName(theme) {
        if (window.themeLoader && window.themeLoader.isReady()) {
            return window.themeLoader.getThemeDisplayName(theme);
        }
        // Fallback
        const themeNames = {
            'light': 'Light',
            'dark': 'Dark',
            'modern': 'Modern',
            'exp-modern': 'Experimental Modern'
        };
        return themeNames[theme] || 'Light';
    }

    // Legacy support - cycles through themes for quiz screen button
    toggleTheme() {
        if (window.themeLoader && window.themeLoader.isReady()) {
            window.themeLoader.cycleTheme();
            this.currentTheme = window.themeLoader.currentTheme;
        } else {
            // Fallback
            const themes = ['light', 'modern'];
            const currentIndex = themes.indexOf(this.currentTheme);
            const nextIndex = (currentIndex + 1) % themes.length;
            this.setTheme(themes[nextIndex]);
        }
    }

    saveTheme() {
        // Theme loader handles saving automatically
        if (!window.themeLoader || !window.themeLoader.isReady()) {
            localStorage.setItem('quizTheme', this.currentTheme);
        }
    }

    loadTheme() {
        if (window.themeLoader && window.themeLoader.isReady()) {
            this.currentTheme = window.themeLoader.currentTheme;
        } else {
            // Fallback
            const savedTheme = localStorage.getItem('quizTheme') || 'light';
            this.currentTheme = savedTheme;
            // Legacy support for old boolean theme storage
            if (savedTheme === 'true' || savedTheme === 'false') {
                this.currentTheme = savedTheme === 'true' ? 'modern' : 'light';
            }
        }
    }

    // Font Management
    setFont(fontName) {
        this.currentFont = fontName;
        this.applyFont();
        this.saveFont();
    }

    applyFont() {
        // Remove existing font classes
        document.body.classList.remove('font-inter', 'font-roboto', 'font-montserrat', 'font-open-sans', 'font-lato');
        
        // Apply new font class
        document.body.classList.add(`font-${this.currentFont}`);
        
        // Update current font display
        const currentFontSpan = document.getElementById('current-font');
        if (currentFontSpan) {
            currentFontSpan.textContent = this.getFontDisplayName(this.currentFont);
        }
    }

    getFontDisplayName(font) {
        const fontNames = {
            'inter': 'Inter',
            'roboto': 'Roboto',
            'montserrat': 'Montserrat',
            'open-sans': 'Open Sans',
            'lato': 'Lato'
        };
        return fontNames[font] || 'Montserrat';
    }

    saveFont() {
        localStorage.setItem('quizFont', this.currentFont);
    }

    loadFont() {
        const savedFont = localStorage.getItem('quizFont') || 'montserrat';
        this.currentFont = savedFont;
    }

    // Screen Management
    showScreen(screenId) {
        const screens = ['welcome-screen', 'config-screen', 'quiz-screen', 'results-screen'];
        screens.forEach(screen => {
            document.getElementById(screen).style.display = 'none';
        });
        document.getElementById(`${screenId}-screen`).style.display = 'block';
    }

    // File Processing
    async processFile(file) {
        try {
            console.log('Processing file:', file.name, 'Size:', file.size, 'bytes');
            const extension = file.name.split('.').pop().toLowerCase();
            console.log('File extension:', extension);
            let data;

            switch (extension) {
                case 'xlsx':
                case 'xls':
                    console.log('Processing Excel file...');
                    data = await this.processExcelFile(file);
                    break;
                case 'csv':
                    console.log('Processing CSV file...');
                    data = await this.processCSVFile(file);
                    break;
                case 'json':
                    console.log('Processing JSON file...');
                    data = await this.processJSONFile(file);
                    break;
                default:
                    throw new Error('Unsupported file format');
            }

            console.log('Raw data received:', data);
            this.quizData = this.validateAndFormatData(data);
            console.log('Validated quiz data:', this.quizData);
            this.saveQuizData();
            this.updateFileInfo(file.name, this.quizData.questions.length);
            document.getElementById('start-quiz-btn').disabled = false;
            console.log('File processed successfully. Start Quiz button enabled.');
            
            return true;
        } catch (error) {
            console.error('Error processing file:', error);
            this.showError(`Error processing file: ${error.message}`);
            return false;
        }
    }

    async processExcelFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                    resolve(jsonData);
                } catch (error) {
                    reject(error);
                }
            };
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsArrayBuffer(file);
        });
    }

    async processCSVFile(file) {
        return new Promise((resolve, reject) => {
            Papa.parse(file, {
                header: false,
                skipEmptyLines: true,
                complete: (results) => {
                    if (results.errors.length > 0) {
                        reject(new Error('CSV parsing error'));
                    } else {
                        resolve(results.data);
                    }
                },
                error: (error) => reject(error)
            });
        });
    }

    async processJSONFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    resolve(data);
                } catch (error) {
                    reject(new Error('Invalid JSON format'));
                }
            };
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsText(file);
        });
    }

    validateAndFormatData(rawData) {
        const questions = [];
        
        // Handle different data formats
        if (Array.isArray(rawData)) {
            if (rawData.length > 0 && typeof rawData[0] === 'object' && !Array.isArray(rawData[0])) {
                // JSON format - array of objects
                this.processJSONData(rawData, questions);
            } else {
                // CSV/Excel format - array of arrays
                this.processArrayData(rawData, questions);
            }
        } else {
            throw new Error('Invalid data format');
        }

        console.log(`Total questions processed: ${questions.length}`);
        
        if (questions.length === 0) {
            throw new Error('No valid questions found in file');
        }

        return {
            questions: questions,
            uploadedAt: new Date().toISOString(),
            fileName: 'uploaded_file'
        };
    }

    processArrayData(rawData, questions) {
        // Skip header row if it exists
        const dataRows = rawData.slice(1);
        
        dataRows.forEach((row, index) => {
            if (!row || row.length < 3) return; // Skip empty rows
            
            const questionText = row[0] || '';
            const correctAnswer = row[1] || ''; // NEW SCHEMA: Column 2
            
            // Skip section headers (rows that start with ===)
            if (questionText.includes('===') || questionText.trim() === '') {
                return;
            }
            
            const question = {
                id: questions.length + 1,
                text: questionText,
                options: [],
                correctAnswer: correctAnswer
            };

            // NEW SCHEMA: Extract options starting from column 3 (index 2)
            for (let i = 2; i < row.length; i++) {
                if (row[i] && row[i].trim() !== '') {
                    question.options.push({
                        letter: String.fromCharCode(65 + (i - 2)), // A, B, C, D, E, F, G...
                        text: row[i].trim()
                    });
                }
            }

            // Validate question - must have text, at least 2 options, and a correct answer
            if (question.text && question.options.length >= 2 && question.correctAnswer) {
                questions.push(question);
                console.log(`Added question: ${question.text} with ${question.options.length} options`);
            } else {
                console.log(`Skipped invalid question: "${question.text}" - Options: ${question.options.length}, Correct Answer: "${question.correctAnswer}"`);
            }
        });
    }

    processJSONData(rawData, questions) {
        rawData.forEach((item, index) => {
            if (!item || typeof item !== 'object') return;
            
            const questionText = item.question || '';
            const correctAnswer = item.correctAnswer || '';
            
            // Skip section headers (rows that start with ===)
            if (questionText.includes('===') || questionText.trim() === '') {
                return;
            }
            
            const question = {
                id: questions.length + 1,
                text: questionText,
                options: [],
                correctAnswer: correctAnswer
            };

            // Extract options from optionA, optionB, optionC, etc.
            const optionKeys = Object.keys(item).filter(key => key.startsWith('option')).sort();
            optionKeys.forEach((key, i) => {
                const optionText = item[key];
                if (optionText && optionText.trim() !== '') {
                    question.options.push({
                        letter: String.fromCharCode(65 + i), // A, B, C, D, E, F, G...
                        text: optionText.trim()
                    });
                }
            });

            // Validate question - must have text, at least 2 options, and a correct answer
            if (question.text && question.options.length >= 2 && question.correctAnswer) {
                questions.push(question);
                console.log(`Added question: ${question.text} with ${question.options.length} options`);
            } else {
                console.log(`Skipped invalid question: "${question.text}" - Options: ${question.options.length}, Correct Answer: "${question.correctAnswer}"`);
            }
        });
    }

    updateFileInfo(fileName, questionCount) {
        document.getElementById('file-name').textContent = fileName;
        document.getElementById('question-count').textContent = questionCount;
        document.getElementById('file-info').style.display = 'block';
    }

    // Quiz Engine
    startQuiz() {
        console.log('Starting quiz...');
        try {
            this.currentQuestionIndex = 0;
            this.userAnswers = {};
            this.quizStartTime = new Date();
            this.timeLimit = parseInt(document.getElementById('quiz-time').value) * 60; // Convert to seconds
            this.studyMode = document.getElementById('study-mode').checked;
            this.selectionCounterEnabled = document.getElementById('selection-counter').checked;
            this.shuffleQuestionsEnabled = document.getElementById('shuffle-questions').checked;
            // V1 option removed from UI but keep property for backward compatibility
            this.shuffleOptionsEnabled = false;
            this.shuffleOptionsV2Enabled = document.getElementById('shuffle-options-v2').checked;
            
            // Store original questions and optionally shuffle
            this.originalQuestions = [...this.quizData.questions];
            if (this.shuffleQuestionsEnabled) {
                this.quizData.questions = this.shuffleArray(this.quizData.questions);
                console.log('Questions shuffled for this attempt');
            }
            
            // Apply option shuffling if enabled
            if (this.shuffleOptionsV2Enabled) {
                // Generate temp CSV data with shuffled options
                this.originalQuizData = JSON.parse(JSON.stringify(this.quizData));
                this.quizData.questions = this.generateTempQuizData();
                console.log('Options shuffled using temp CSV approach');
            }
            
            console.log('Quiz settings:', {
                timeLimit: this.timeLimit,
                studyMode: this.studyMode,
                shuffleQuestionsEnabled: this.shuffleQuestionsEnabled,
                shuffleOptionsEnabled: this.shuffleOptionsV2Enabled,
                questionsCount: this.quizData.questions.length
            });
            
            this.saveProgress();
            this.showScreen('quiz');
            this.displayQuestion();
            this.updateProgress();
            this.startTimer();
            this.createQuestionNavigation();
            this.updateShowAnswerButton();
            console.log('Quiz started successfully');
        } catch (error) {
            console.error('Error starting quiz:', error);
            alert('Error starting quiz: ' + error.message);
        }
    }

    displayQuestion() {
        const question = this.quizData.questions[this.currentQuestionIndex];
        document.getElementById('question-text').textContent = question.text;
        
        const answerOptions = document.getElementById('answer-options');
        answerOptions.innerHTML = '';
        
        // Check if this is a multiple correct answer question
        const isMultipleCorrect = question.correctAnswer.includes(',');
        
        // Add selection counter for multiple correct answer questions
        if (isMultipleCorrect && this.selectionCounterEnabled) {
            const correctCount = question.correctAnswer.split(',').length;
            const instructionDiv = document.createElement('div');
            instructionDiv.className = 'alert alert-info selection-counter-alert mb-3';
            instructionDiv.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="bi bi-info-circle me-2"></i>
                    <div>
                        <strong>Select ${correctCount} option${correctCount > 1 ? 's' : ''}:</strong>
                        <span id="selection-counter-display" class="ms-2 badge bg-primary">
                            <span id="current-count">0</span> of ${correctCount} selected
                        </span>
                    </div>
                </div>
            `;
            answerOptions.appendChild(instructionDiv);
        }
        
        question.options.forEach((option, index) => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'answer-option';
            optionDiv.dataset.letter = option.letter;
            optionDiv.dataset.index = index;
            optionDiv.dataset.originalText = option.text;
            
            // Check if this option is selected (compare using original letters)
            const userAnswers = this.userAnswers[this.currentQuestionIndex];
            const originalLetter = option.originalLetter || option.letter;
            const isSelected = isMultipleCorrect 
                ? (userAnswers && userAnswers.split(',').map(a => a.trim()).includes(originalLetter))
                : (userAnswers === originalLetter);
            
            if (isSelected) optionDiv.classList.add('selected');
            
            // Add checkbox for multi-select questions
            const checkbox = isMultipleCorrect ? '<input type="checkbox" class="form-check-input me-3">' : '';
            
            optionDiv.innerHTML = `
                ${checkbox}<strong>${option.letter}.</strong>&nbsp;&nbsp;${option.text}
            `;
            
            if (isMultipleCorrect) {
                // For multi-select, toggle selection
                optionDiv.addEventListener('click', () => this.toggleMultiSelectAnswer(option.letter));
            } else {
                // For single select, replace selection
                optionDiv.addEventListener('click', () => this.selectAnswer(option.letter));
            }
            
            answerOptions.appendChild(optionDiv);
        });
        
        this.updateNavigationButtons();
        this.updateShowAnswerButton();
        
        // Update multi-select UI to show current selection count
        if (isMultipleCorrect) {
            this.updateMultiSelectUI();
        }
    }

    selectAnswer(letter) {
        // Store original letter, not shuffled letter
        const originalLetter = this.getOriginalLetter(letter);
        this.userAnswers[this.currentQuestionIndex] = originalLetter;
        this.saveProgress();
        
        // Update UI (still use shuffled letter for display)
        document.querySelectorAll('.answer-option').forEach(option => {
            option.classList.remove('selected');
        });
        document.querySelector(`[data-letter="${letter}"]`).classList.add('selected');
        
        this.updateShowAnswerButton();
    }

    toggleMultiSelectAnswer(letter) {
        // Convert shuffled letter to original for storage
        const originalLetter = this.getOriginalLetter(letter);
        
        const currentAnswers = this.userAnswers[this.currentQuestionIndex] || '';
        const answersArray = currentAnswers ? currentAnswers.split(',').map(a => a.trim()) : [];
        
        if (answersArray.includes(originalLetter)) {
            // Remove the original letter if already selected
            const newAnswersArray = answersArray.filter(a => a !== originalLetter);
            this.userAnswers[this.currentQuestionIndex] = newAnswersArray.join(',');
        } else {
            // Add the original letter if not selected
            answersArray.push(originalLetter);
            this.userAnswers[this.currentQuestionIndex] = answersArray.join(',');
        }
        
        this.saveProgress();
        
        // Update UI
        this.updateMultiSelectUI();
        this.updateShowAnswerButton();
    }

    updateMultiSelectUI() {
        const currentAnswers = this.userAnswers[this.currentQuestionIndex] || '';
        const answersArray = currentAnswers ? currentAnswers.split(',').map(a => a.trim()) : [];
        
        document.querySelectorAll('.answer-option').forEach(option => {
            const shuffledLetter = option.dataset.letter;
            const originalLetter = this.getOriginalLetter(shuffledLetter);
            const checkbox = option.querySelector('input[type="checkbox"]');
            
            // Check if original letter is in user answers
            if (answersArray.includes(originalLetter)) {
                option.classList.add('selected');
                if (checkbox) checkbox.checked = true;
            } else {
                option.classList.remove('selected');
                if (checkbox) checkbox.checked = false;
            }
        });
        
        // Update selection counter if enabled
        if (this.selectionCounterEnabled) {
            const selectedCount = answersArray.filter(a => a.trim()).length;
            const counterElement = document.getElementById('current-count');
            if (counterElement) {
                counterElement.textContent = selectedCount;
                
                // Update badge color based on selection progress
                const badge = document.getElementById('selection-counter-display');
                if (badge) {
                    const question = this.quizData.questions[this.currentQuestionIndex];
                    const correctCount = question.correctAnswer.split(',').length;
                    
                    badge.className = 'ms-2 badge';
                    if (selectedCount === 0) {
                        badge.classList.add('bg-secondary');
                    } else if (selectedCount < correctCount) {
                        badge.classList.add('bg-warning');
                    } else if (selectedCount === correctCount) {
                        badge.classList.add('bg-success');
                    } else {
                        badge.classList.add('bg-danger');
                    }
                }
            }
        }
    }

    updateShowAnswerButton() {
        const showAnswerBtn = document.getElementById('show-answer-btn');
        if (this.studyMode) {
            showAnswerBtn.style.display = 'inline-block';
        } else {
            showAnswerBtn.style.display = 'none';
        }
    }

    showCorrectAnswer() {
        const question = this.quizData.questions[this.currentQuestionIndex];
        const userAnswer = this.userAnswers[this.currentQuestionIndex];
        const isMultipleCorrect = question.correctAnswer.includes(',');
        
        document.querySelectorAll('.answer-option').forEach(option => {
            const shuffledLetter = option.dataset.letter;
            const originalLetter = this.getOriginalLetter(shuffledLetter);
            const originalText = option.dataset.originalText;
            const isCorrect = this.isAnswerCorrect(originalLetter, question.correctAnswer);
            
            // Check if user selected this option (using original letters)
            const userAnswers = userAnswer ? userAnswer.split(',').map(a => a.trim()) : [];
            const isUserAnswer = isMultipleCorrect 
                ? userAnswers.includes(originalLetter)
                : (originalLetter === userAnswer);
            
            if (isCorrect) {
                option.classList.add('correct');
                option.innerHTML = `<strong>${shuffledLetter}.</strong> ${originalText} ✅`;
            } else if (isUserAnswer && !isCorrect) {
                option.classList.add('incorrect');
                option.innerHTML = `<strong>${shuffledLetter}.</strong> ${originalText} ❌`;
            } else {
                option.innerHTML = `<strong>${shuffledLetter}.</strong> ${originalText}`;
            }
        });
    }

    isAnswerCorrect(selectedAnswer, correctAnswer) {
        const correctAnswers = correctAnswer.split(',').map(ans => ans.trim().toUpperCase());
        return correctAnswers.includes(selectedAnswer.toUpperCase());
    }

    // Fisher-Yates Shuffle Algorithm
    shuffleArray(array) {
        const shuffled = [...array]; // Create copy to avoid mutating original
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]; // Swap elements
        }
        return shuffled;
    }

    // Dual-Layer Option Shuffling
    shuffleQuestionOptions(question) {
        if (!question.options || question.options.length <= 1) {
            return; // No need to shuffle single or no options
        }

        // Store original options before shuffling
        question.originalOptions = [...question.options];
        
        // Create shuffled copy
        const shuffledOptions = this.shuffleArray(question.options);
        
        // Reassign letters A, B, C, D, E... to shuffled positions
        shuffledOptions.forEach((option, index) => {
            option.originalLetter = option.letter; // Store original letter
            option.letter = String.fromCharCode(65 + index); // Assign new letter A, B, C...
        });
        
        // Create mapping from shuffled letter to original letter
        question.shuffleMap = {};
        shuffledOptions.forEach(option => {
            question.shuffleMap[option.letter] = option.originalLetter;
        });
        
        // Update question options to use shuffled version
        question.options = shuffledOptions;
        
        console.log(`Question "${question.text.substring(0, 50)}..." shuffle map:`, question.shuffleMap);
    }

    // Get original letter from shuffled letter (V1 approach)
    getOriginalLetter(shuffledLetter, questionIndex = null) {
        const qIndex = questionIndex !== null ? questionIndex : this.currentQuestionIndex;
        const question = this.quizData.questions[qIndex];
        
        if (question.shuffleMap && question.shuffleMap[shuffledLetter]) {
            return question.shuffleMap[shuffledLetter];
        }
        
        return shuffledLetter; // Return as-is if no shuffle mapping
    }

    // ================================
    // V2 SHUFFLE APPROACH - TEMP CSV
    // ================================

    // Transform correct answer using forward mapping (original → temp)
    transformCorrectAnswer(originalAnswer, forwardMap) {
        if (!originalAnswer || !forwardMap) {
            return originalAnswer;
        }
        
        return originalAnswer
            .split(',')
            .map(letter => forwardMap[letter.trim()] || letter.trim())
            .join(',');
    }

    // Generate temp quiz data with shuffled options (V2 approach)
    generateTempQuizData() {
        console.log('Generating temp quiz data (V2 approach)...');
        
        return this.quizData.questions.map((question, qIndex) => {
            // Skip shuffling if disabled or only 1 option
            if (!this.shuffleOptionsV2Enabled || question.options.length <= 1) {
                return { 
                    ...question, 
                    shuffleMapping: null,
                    isV2Shuffled: false 
                };
            }
            
            // Create shuffle mapping
            const originalOptions = [...question.options];
            const shuffledOptions = this.shuffleArray(originalOptions);
            
            // Build forward/reverse maps
            const forwardMap = {};
            const reverseMap = {};
            
            originalOptions.forEach((option, origIndex) => {
                const shuffledIndex = shuffledOptions.findIndex(opt => opt.text === option.text);
                const origLetter = String.fromCharCode(65 + origIndex);
                const shuffledLetter = String.fromCharCode(65 + shuffledIndex);
                
                forwardMap[origLetter] = shuffledLetter;
                reverseMap[shuffledLetter] = origLetter;
            });
            
            // Transform correct answer to temp format
            const tempCorrectAnswer = this.transformCorrectAnswer(
                question.correctAnswer, 
                forwardMap
            );
            
            console.log(`Q${qIndex + 1} V2 mapping:`, { 
                original: question.correctAnswer, 
                temp: tempCorrectAnswer, 
                forwardMap 
            });
            
            return {
                ...question,
                options: shuffledOptions.map((option, index) => ({
                    ...option,
                    letter: String.fromCharCode(65 + index)
                })),
                correctAnswer: tempCorrectAnswer,
                shuffleMapping: { forwardMap, reverseMap },
                isV2Shuffled: true
            };
        });
    }

    nextQuestion() {
        if (this.currentQuestionIndex < this.quizData.questions.length - 1) {
            this.currentQuestionIndex++;
            this.displayQuestion();
            this.updateProgress();
            
            // Smooth scroll to quiz interface header
            setTimeout(() => {
                const quizHeader = document.getElementById('quiz-interface-header');
                if (quizHeader) {
                    quizHeader.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'start',
                        inline: 'nearest'
                    });
                }
            }, 100); // Small delay to ensure question display completes
        } else {
            this.finishQuiz();
        }
    }

    previousQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
            this.displayQuestion();
            this.updateProgress();
            
            // Smooth scroll to quiz interface header
            setTimeout(() => {
                const quizHeader = document.getElementById('quiz-interface-header');
                if (quizHeader) {
                    quizHeader.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'start',
                        inline: 'nearest'
                    });
                }
            }, 100); // Small delay to ensure question display completes
        }
    }

    goToQuestion(index) {
        this.currentQuestionIndex = index;
        this.displayQuestion();
        this.updateProgress();
        
        // Smooth scroll to quiz interface header
        setTimeout(() => {
            const quizHeader = document.getElementById('quiz-interface-header');
            if (quizHeader) {
                quizHeader.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start',
                    inline: 'nearest'
                });
            }
        }, 100); // Small delay to ensure question display completes
    }

    updateProgress() {
        const progress = ((this.currentQuestionIndex + 1) / this.quizData.questions.length) * 100;
        document.getElementById('progress-bar').style.width = `${progress}%`;
        document.getElementById('progress-text').textContent = 
            `Question ${this.currentQuestionIndex + 1} of ${this.quizData.questions.length}`;
    }

    createQuestionNavigation() {
        const navContainer = document.getElementById('question-nav');
        navContainer.innerHTML = '';
        navContainer.className = 'question-nav'; // Add the CSS class for proper styling
        
        // Create a grid container for better organization
        const gridContainer = document.createElement('div');
        gridContainer.className = 'question-nav-grid';
        
        this.quizData.questions.forEach((_, index) => {
            const btn = document.createElement('button');
            btn.className = 'question-nav-btn';
            btn.textContent = index + 1;
            btn.addEventListener('click', () => this.goToQuestion(index));
            gridContainer.appendChild(btn);
        });
        
        navContainer.appendChild(gridContainer);
        this.updateQuestionNavigation();
    }

    updateQuestionNavigation() {
        document.querySelectorAll('.question-nav-btn').forEach((btn, index) => {
            btn.classList.remove('answered', 'current');
            
            if (index === this.currentQuestionIndex) {
                btn.classList.add('current');
            } else if (this.userAnswers[index]) {
                btn.classList.add('answered');
            }
        });
    }

    updateNavigationButtons() {
        document.getElementById('prev-btn').disabled = this.currentQuestionIndex === 0;
        const isLastQuestion = this.currentQuestionIndex === this.quizData.questions.length - 1;
        document.getElementById('next-btn').textContent = isLastQuestion ? 'Finish Quiz' : 'Next →';
        this.updateQuestionNavigation();
    }

    // Timer Management
    startTimer() {
        this.timerInterval = setInterval(() => {
            const elapsed = Math.floor((new Date() - this.quizStartTime) / 1000);
            const remaining = this.timeLimit - elapsed;
            
            if (remaining <= 0) {
                this.finishQuiz();
                return;
            }
            
            const minutes = Math.floor(remaining / 60);
            const seconds = remaining % 60;
            document.getElementById('timer').textContent = 
                `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }, 1000);
    }

    stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
        }
    }

    // Results
    finishQuiz() {
        this.stopTimer();
        this.quizEndTime = new Date();
        
        const results = this.calculateResults();
        this.displayResults(results);
        this.showScreen('results');
        
        // Smooth scroll to the quiz results header
        setTimeout(() => {
            const resultsHeader = document.getElementById('quiz-results-header');
            if (resultsHeader) {
                resultsHeader.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start',
                    inline: 'nearest'
                });
            }
        }, 100); // Small delay to ensure screen transition completes
    }

    calculateResults() {
        let correct = 0;
        const incorrectAnswers = [];
        
        this.quizData.questions.forEach((question, index) => {
            const userAnswer = this.userAnswers[index];
            const isMultipleCorrect = question.correctAnswer.includes(',');
            
            let isCorrect = false;
            
            if (isMultipleCorrect) {
                // For multi-select questions, check if all correct answers are selected
                const correctAnswers = question.correctAnswer.split(',').map(a => a.trim().toUpperCase());
                const userAnswers = userAnswer ? userAnswer.split(',').map(a => a.trim().toUpperCase()) : [];
                
                // Check if user selected exactly the correct answers (no extra, no missing)
                const hasAllCorrect = correctAnswers.every(ans => userAnswers.includes(ans));
                const hasNoExtra = userAnswers.every(ans => correctAnswers.includes(ans));
                isCorrect = hasAllCorrect && hasNoExtra;
            } else {
                // For single answer questions
                isCorrect = userAnswer && this.isAnswerCorrect(userAnswer, question.correctAnswer);
            }
            
            if (isCorrect) {
                correct++;
            } else {
                incorrectAnswers.push({
                    question: question,
                    userAnswer: userAnswer,
                    correctAnswer: question.correctAnswer
                });
            }
        });
        
        return {
            total: this.quizData.questions.length,
            correct: correct,
            incorrect: this.quizData.questions.length - correct,
            percentage: Math.round((correct / this.quizData.questions.length) * 100),
            incorrectAnswers: incorrectAnswers
        };
    }

    displayResults(results) {
        document.getElementById('score-display').textContent = 
            `${results.correct}/${results.total} Correct`;
        document.getElementById('score-percentage').textContent = 
            `${results.percentage}% Score`;
        
        const incorrectList = document.getElementById('incorrect-list');
        incorrectList.innerHTML = '';
        
        if (results.incorrectAnswers.length === 0) {
            incorrectList.innerHTML = '<p class="text-success">Perfect! All answers correct.</p>';
        } else {
            results.incorrectAnswers.forEach(item => {
                const div = document.createElement('div');
                div.className = 'incorrect-answer-item';
                
                // Build options list
                let optionsHtml = '';
                item.question.options.forEach(option => {
                    // Use original letters for validation
                    const originalLetter = option.originalLetter || option.letter;
                    
                    // Handle both single and multi-select user answers
                    const userAnswers = item.userAnswer ? item.userAnswer.split(',').map(a => a.trim()) : [];
                    const isUserAnswer = userAnswers.includes(originalLetter);
                    const isCorrectAnswer = this.isAnswerCorrect(originalLetter, item.correctAnswer);
                    let optionClass = '';
                    let optionIcon = '';
                    
                    if (isUserAnswer && isCorrectAnswer) {
                        optionClass = 'text-success fw-bold';
                        optionIcon = ' ✅';
                    } else if (isUserAnswer && !isCorrectAnswer) {
                        optionClass = 'text-danger fw-bold';
                        optionIcon = ' ❌';
                    } else if (isCorrectAnswer) {
                        optionClass = 'text-success fw-bold';
                        optionIcon = ' ✅';
                    }
                    
                    optionsHtml += `<div class="${optionClass}">${option.letter}. ${option.text}${optionIcon}</div>`;
                });
                
                div.innerHTML = `
                    <div class="question fw-bold mb-2">${item.question.text}</div>
                    <div class="options mb-2">
                        ${optionsHtml}
                    </div>
                    <div class="summary">
                        <span class="text-danger">Your answer: ${item.userAnswer || 'Not answered'}</span> | 
                        <span class="text-success">Correct answer: ${item.correctAnswer}</span>
                    </div>
                `;
                incorrectList.appendChild(div);
            });
        }
    }

    // Utility Functions

    // Data Persistence
    saveQuizData() {
        localStorage.setItem('quizData', JSON.stringify(this.quizData));
    }

    saveProgress() {
        const progress = {
            currentQuestionIndex: this.currentQuestionIndex,
            userAnswers: this.userAnswers,
            quizStartTime: this.quizStartTime,
            timeLimit: this.timeLimit,
            studyMode: this.studyMode
        };
        localStorage.setItem('quizProgress', JSON.stringify(progress));
    }

    loadSavedData() {
        this.loadTheme();
        this.loadFont();
        
        const savedQuizData = localStorage.getItem('quizData');
        if (savedQuizData) {
            try {
                this.quizData = JSON.parse(savedQuizData);
                this.updateFileInfo(this.quizData.fileName, this.quizData.questions.length);
                document.getElementById('start-quiz-btn').disabled = false;
                console.log('Loaded saved quiz data:', this.quizData.questions.length, 'questions');
            } catch (error) {
                console.error('Error loading saved quiz data:', error);
                localStorage.removeItem('quizData');
            }
        } else {
            console.log('No saved quiz data found. Please upload a file.');
        }
        
        const savedProgress = localStorage.getItem('quizProgress');
        if (savedProgress) {
            try {
                const progress = JSON.parse(savedProgress);
                this.currentQuestionIndex = progress.currentQuestionIndex || 0;
                this.userAnswers = progress.userAnswers || {};
                this.quizStartTime = progress.quizStartTime ? new Date(progress.quizStartTime) : null;
                this.timeLimit = progress.timeLimit || 0;
                this.studyMode = progress.studyMode || false;
                console.log('Loaded saved progress');
            } catch (error) {
                console.error('Error loading saved progress:', error);
                localStorage.removeItem('quizProgress');
            }
        }
    }

    clearSavedData() {
        localStorage.removeItem('quizData');
        localStorage.removeItem('quizProgress');
        // Ensure button is disabled when data is cleared
        document.getElementById('start-quiz-btn').disabled = true;
        // Hide file info
        document.getElementById('file-info').style.display = 'none';
    }

    // Error Handling
    showError(message) {
        alert(message); // Simple error display for POC
    }

    // Event Listeners
    setupEventListeners() {
        try {
            // Theme change event listener
            window.addEventListener('themeChanged', (e) => {
                console.log('Theme changed from', e.detail.oldTheme, 'to', e.detail.newTheme);
                // Refresh question navigation when theme changes during quiz
                if (this.quizData && document.getElementById('quiz-screen').style.display !== 'none') {
                    this.updateQuestionNavigation();
                }
            });

            // Theme dropdown listeners
            document.querySelectorAll('[data-theme]').forEach(item => {
                item.addEventListener('click', (e) => {
                    e.preventDefault();
                    const theme = e.target.getAttribute('data-theme') || e.target.closest('[data-theme]').getAttribute('data-theme');
                    this.setTheme(theme);
                });
            });
            
            // Legacy theme toggle for quiz screen
            const quizThemeToggle = document.getElementById('theme-toggle-quiz');
            if (quizThemeToggle) {
                quizThemeToggle.addEventListener('click', () => this.toggleTheme());
            }

            // Font dropdown listeners
            document.querySelectorAll('[data-font]').forEach(item => {
                item.addEventListener('click', (e) => {
                    e.preventDefault();
                    const font = e.target.getAttribute('data-font') || e.target.closest('[data-font]').getAttribute('data-font');
                    this.setFont(font);
                });
            });
        
        // File upload
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('file-input');
        
        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file) this.processFile(file);
        });
        
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) this.processFile(file);
        });
        
        // Navigation buttons
        document.getElementById('start-quiz-btn').addEventListener('click', () => {
            console.log('Start Quiz button clicked');
            this.showScreen('config');
            this.updateConfigScreen();
            // Smooth scroll to the configuration header
            setTimeout(() => {
                const configHeader = document.getElementById('quiz-configuration-header');
                if (configHeader) {
                    configHeader.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'start',
                        inline: 'nearest'
                    });
                }
            }, 100); // Small delay to ensure screen transition completes
        });
        
        document.getElementById('start-quiz-config').addEventListener('click', () => {
            console.log('Start Quiz Config button clicked');
            this.startQuiz();
            // Smooth scroll to the quiz question section
            setTimeout(() => {
                const questionSection = document.getElementById('quiz-question-section');
                if (questionSection) {
                    questionSection.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'start',
                        inline: 'nearest'
                    });
                }
            }, 100); // Small delay to ensure screen transition completes
        });
        
        document.getElementById('prev-btn').addEventListener('click', () => this.previousQuestion());
        document.getElementById('next-btn').addEventListener('click', () => this.nextQuestion());
        document.getElementById('show-answer-btn').addEventListener('click', () => this.showCorrectAnswer());
        
        document.getElementById('restart-quiz').addEventListener('click', () => this.restartQuiz());
        document.getElementById('new-file').addEventListener('click', () => this.newFile());
        
        } catch (error) {
            console.error('Error setting up event listeners:', error);
        }
    }

    updateConfigScreen() {
        if (this.quizData) {
            document.getElementById('total-questions').textContent = this.quizData.questions.length;
            const calculatedTime = Math.ceil(this.quizData.questions.length * 1.17); // 1min 10sec per question
            document.getElementById('calculated-time').textContent = calculatedTime;
            document.getElementById('quiz-time').value = calculatedTime;
        }
    }

    restartQuiz() {
        // Reset questions to original order before restart
        if (this.originalQuestions) {
            this.quizData.questions = [...this.originalQuestions];
        }
        this.clearSavedData();
        
        // Reset all quiz state
        this.currentQuestionIndex = 0;
        this.userAnswers = [];
        this.startTime = null;
        this.endTime = null;
        this.timer = null;
        
        // Scroll to top and show welcome screen
        window.scrollTo(0, 0);
        this.showScreen('welcome');
    }

    newFile() {
        this.clearSavedData();
        this.showScreen('welcome');
        location.reload(); // Simple restart for POC
    }

}

// Template Download Functions
function downloadTemplate(type) {
    let content, filename, mimeType;
    
    switch (type) {
        case 'excel':
            // For POC, we'll create a CSV that can be opened in Excel
            content = `Question,Correct Answer,Option A,Option B,Option C,Option D,Option E
"What is cloud computing?",A,A distributed computing model,Local server hosting,Desktop application,None of the above,All of the above
"What is AWS?",A,Amazon Web Services,Apple Web Services,Azure Web Services,Google Web Services,Microsoft Web Services
"Which cloud service model provides most control?",A,IaaS,PaaS,SaaS,Serverless
"Which is NOT a cloud provider?",C,AWS,Azure,Local Server
"What is virtualization?",A,Creating virtual resources,Physical hardware,Network configuration
"Cloud computing provides on-demand resources?",A,True,False
"AWS stands for Amazon Web Services?",A,True,False
"Local servers are considered cloud computing?",B,True,False
"Which are cloud providers? (Select all that apply)","A,B,C",Amazon Web Services,Microsoft Azure,Google Cloud,Local Server,Desktop App`;
            filename = 'quiz-template.csv';
            mimeType = 'text/csv';
            break;
        case 'csv':
            content = `Question,Correct Answer,Option A,Option B,Option C,Option D,Option E
"What is cloud computing?",A,A distributed computing model,Local server hosting,Desktop application,None of the above,All of the above
"What is AWS?",A,Amazon Web Services,Apple Web Services,Azure Web Services,Google Web Services,Microsoft Web Services
"Which cloud service model provides most control?",A,IaaS,PaaS,SaaS,Serverless
"Which is NOT a cloud provider?",C,AWS,Azure,Local Server
"What is virtualization?",A,Creating virtual resources,Physical hardware,Network configuration
"Cloud computing provides on-demand resources?",A,True,False
"AWS stands for Amazon Web Services?",A,True,False
"Local servers are considered cloud computing?",B,True,False
"Which are cloud providers? (Select all that apply)","A,B,C",Amazon Web Services,Microsoft Azure,Google Cloud,Local Server,Desktop App`;
            filename = 'quiz-template.csv';
            mimeType = 'text/csv';
            break;
        case 'json':
            content = JSON.stringify([
                {
                    "question": "What is cloud computing?",
                    "optionA": "A distributed computing model",
                    "optionB": "Local server hosting",
                    "optionC": "Desktop application",
                    "optionD": "None of the above",
                    "optionE": "All of the above",
                    "correctAnswer": "A"
                },
                {
                    "question": "What is AWS?",
                    "optionA": "Amazon Web Services",
                    "optionB": "Apple Web Services",
                    "optionC": "Azure Web Services",
                    "optionD": "Google Web Services",
                    "optionE": "Microsoft Web Services",
                    "correctAnswer": "A"
                },
                {
                    "question": "Which cloud service model provides most control?",
                    "optionA": "IaaS",
                    "optionB": "PaaS",
                    "optionC": "SaaS",
                    "optionD": "Serverless",
                    "optionE": "",
                    "correctAnswer": "A"
                },
                {
                    "question": "Which is NOT a cloud provider?",
                    "optionA": "AWS",
                    "optionB": "Azure",
                    "optionC": "Local Server",
                    "optionD": "",
                    "optionE": "",
                    "correctAnswer": "C"
                },
                {
                    "question": "What is virtualization?",
                    "optionA": "Creating virtual resources",
                    "optionB": "Physical hardware",
                    "optionC": "Network configuration",
                    "optionD": "",
                    "optionE": "",
                    "correctAnswer": "A"
                },
                {
                    "question": "Cloud computing provides on-demand resources?",
                    "optionA": "True",
                    "optionB": "False",
                    "optionC": "",
                    "optionD": "",
                    "optionE": "",
                    "correctAnswer": "A"
                },
                {
                    "question": "AWS stands for Amazon Web Services?",
                    "optionA": "True",
                    "optionB": "False",
                    "optionC": "",
                    "optionD": "",
                    "optionE": "",
                    "correctAnswer": "A"
                },
                {
                    "question": "Local servers are considered cloud computing?",
                    "optionA": "True",
                    "optionB": "False",
                    "optionC": "",
                    "optionD": "",
                    "optionE": "",
                    "correctAnswer": "B"
                },
                {
                    "question": "Which are cloud providers? (Select all that apply)",
                    "optionA": "Amazon Web Services",
                    "optionB": "Microsoft Azure",
                    "optionC": "Google Cloud",
                    "optionD": "Local Server",
                    "optionE": "Desktop App",
                    "correctAnswer": "A,B,C"
                }
            ], null, 2);
            filename = 'quiz-template.json';
            mimeType = 'application/json';
            break;
    }
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new QuizApp();
});
