/**
 * Theme Loader - Dynamic Theme Management System
 * Handles loading, switching, and managing themes for the Quiz App
 */

class ThemeLoader {
    constructor() {
        this.themes = new Map();
        this.currentTheme = 'light';
        this.themeLinks = new Map();
        this.initialized = false;
    }

    /**
     * Initialize the theme system
     */
    async init() {
        try {
            await this.loadThemeMetadata();
            await this.loadAllThemes();
            this.loadSavedTheme();
            this.applyTheme(this.currentTheme);
            this.initialized = true;
            console.log('Theme system initialized successfully');
        } catch (error) {
            console.error('Failed to initialize theme system:', error);
            // Fallback to default theme
            this.currentTheme = 'light';
        }
    }

    /**
     * Load theme metadata from themes.json
     */
    async loadThemeMetadata() {
        try {
            console.log('Loading themes.json...');
            const response = await fetch('themes/themes.json');
            if (!response.ok) {
                throw new Error(`Failed to load themes.json: ${response.status}`);
            }
            const data = await response.json();
            console.log('Themes.json loaded successfully:', data);
            
            // Store theme metadata
            data.themes.forEach(theme => {
                this.themes.set(theme.id, theme);
                console.log(`Registered theme: ${theme.id} -> ${theme.name}`);
            });
            
            console.log(`Loaded ${data.themes.length} theme definitions`);
        } catch (error) {
            console.error('Error loading theme metadata:', error);
            // Fallback theme definitions
            this.themes.set('light', {
                id: 'light',
                name: 'Light',
                file: 'light.css',
                preview: 'linear-gradient(135deg, #2196F3, #1976D2)',
                isDefault: true
            });
            this.themes.set('dark', {
                id: 'dark',
                name: 'Dark',
                file: 'dark.css',
                preview: 'linear-gradient(135deg, #1a1a1a, #333333)',
                isDefault: false
            });
            this.themes.set('modern', {
                id: 'modern',
                name: 'Modern',
                file: 'modern.css',
                preview: 'linear-gradient(135deg, #8B5CF6, #EC4899)',
                isDefault: false
            });
            this.themes.set('exp-modern', {
                id: 'exp-modern',
                name: 'Experimental Modern',
                file: 'exp-modern.css',
                preview: 'linear-gradient(135deg, #FF6B6B, #4ECDC4)',
                isDefault: false
            });
            console.log('Using fallback theme definitions');
        }
    }

    /**
     * Load all theme CSS files
     */
    async loadAllThemes() {
        const head = document.head;
        console.log('Loading theme CSS files...');
        
        for (const [themeId, themeData] of this.themes) {
            try {
                console.log(`Loading CSS for theme: ${themeId} (${themeData.file})`);
                // Create link element for theme CSS
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = `themes/${themeData.file}`;
                link.id = `theme-${themeId}`;
                link.disabled = true; // Start disabled
                
                // Add to document head
                head.appendChild(link);
                
                // Store reference
                this.themeLinks.set(themeId, link);
                
                console.log(`Loaded theme: ${themeData.name}`);
            } catch (error) {
                console.error(`Failed to load theme ${themeId}:`, error);
            }
        }
        console.log('All theme CSS files loaded. Available themes:', Array.from(this.themeLinks.keys()));
    }

    /**
     * Apply a specific theme
     */
    applyTheme(themeId) {
        console.log(`Attempting to apply theme: ${themeId}`);
        console.log('Available themes:', Array.from(this.themes.keys()));
        
        if (!this.themes.has(themeId)) {
            console.warn(`Theme ${themeId} not found, falling back to light`);
            themeId = 'light';
        }

        // Disable all themes
        for (const [id, link] of this.themeLinks) {
            link.disabled = true;
        }

        // Enable selected theme
        const selectedLink = this.themeLinks.get(themeId);
        if (selectedLink) {
            selectedLink.disabled = false;
            this.currentTheme = themeId;
            this.saveTheme();
            this.updateThemeDisplay();
            
            console.log(`Applied theme: ${this.getThemeDisplayName(themeId)}`);
        } else {
            console.error(`Theme link not found for: ${themeId}`);
        }
    }

    /**
     * Switch to a different theme
     */
    switchTheme(themeId) {
        if (this.currentTheme === themeId) {
            return; // Already active
        }
        
        this.applyTheme(themeId);
        
        // Dispatch theme change event
        window.dispatchEvent(new CustomEvent('themeChanged', {
            detail: {
                oldTheme: this.currentTheme,
                newTheme: themeId,
                themeData: this.themes.get(themeId)
            }
        }));
    }

    /**
     * Get available themes
     */
    getAvailableThemes() {
        return Array.from(this.themes.values());
    }

    /**
     * Get current theme data
     */
    getCurrentTheme() {
        return this.themes.get(this.currentTheme);
    }

    /**
     * Get theme display name
     */
    getThemeDisplayName(themeId) {
        const theme = this.themes.get(themeId);
        return theme ? theme.name : 'Unknown';
    }

    /**
     * Get theme preview gradient
     */
    getThemePreview(themeId) {
        const theme = this.themes.get(themeId);
        return theme ? theme.preview : '';
    }

    /**
     * Cycle to next theme (for legacy support)
     */
    cycleTheme() {
        const themeIds = Array.from(this.themes.keys());
        const currentIndex = themeIds.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % themeIds.length;
        const nextTheme = themeIds[nextIndex];
        
        this.switchTheme(nextTheme);
    }

    /**
     * Save current theme to localStorage
     */
    saveTheme() {
        localStorage.setItem('quizTheme', this.currentTheme);
    }

    /**
     * Load saved theme from localStorage
     */
    loadSavedTheme() {
        const savedTheme = localStorage.getItem('quizTheme') || 'light';
        
        // Handle legacy boolean storage
        if (savedTheme === 'true' || savedTheme === 'false') {
            this.currentTheme = savedTheme === 'true' ? 'modern' : 'light';
        } else if (this.themes.has(savedTheme)) {
            this.currentTheme = savedTheme;
        } else {
            this.currentTheme = 'light';
        }
    }

    /**
     * Update theme display in UI
     */
    updateThemeDisplay() {
        const currentThemeSpan = document.getElementById('current-theme');
        if (currentThemeSpan) {
            currentThemeSpan.textContent = this.getThemeDisplayName(this.currentTheme);
        }
    }

    /**
     * Generate theme dropdown HTML
     */
    generateThemeDropdown() {
        let html = '';
        
        for (const theme of this.themes.values()) {
            html += `
                <li><a class="dropdown-item" href="#" data-theme="${theme.id}">
                    <span class="theme-preview" style="background: ${theme.preview}"></span> ${theme.name}
                </a></li>
            `;
        }
        
        return html;
    }

    /**
     * Check if theme system is ready
     */
    isReady() {
        return this.initialized;
    }
}

// Create global theme loader instance
window.themeLoader = new ThemeLoader();

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.themeLoader.init();
    });
} else {
    window.themeLoader.init();
}
